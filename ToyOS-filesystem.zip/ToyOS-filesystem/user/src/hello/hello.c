#include "../lib/user.h"

char s[] = "\n\
                                                      \n\
_|_|_|_|_|                          _|_|      _|_|_|  \n\
    _|      _|_|    _|    _|      _|    _|  _|        \n\
    _|    _|    _|  _|    _|      _|    _|    _|_|    \n\
    _|    _|    _|  _|    _|      _|    _|        _|  \n\
    _|      _|_|      _|_|_|        _|_|    _|_|_|    \n\
                          _|                          \n\
                      _|_|                            \n\n\
                                By RiversJin based on xv6-riscv\n\
                                Hello, the World ~~\n";

int main(){
    printf("%s",s);
    exit(0);
}