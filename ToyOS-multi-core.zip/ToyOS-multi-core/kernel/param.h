#ifndef PARAM_H
#define PARAM_H

#define NCPU 4 // cpu数量

#endif /* PARAM_H */