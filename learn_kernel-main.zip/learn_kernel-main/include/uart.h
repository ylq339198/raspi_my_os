
void uart_send(char c);
char uart_recv(void);
void uart_send_string(char *str);
void uart_init(void);
void _putchar(char character);
