
#include <stddef.h>
void memcpy(void *dst, void *src,size_t num);