#ifndef MACRO_DEBUG_H
#define MACRO_DEBUG_H

#define XSTR(x) STR(x)
#define STR(x) #x

#endif // MACRO_DEBUG_H