#ifndef SYSPROC_H
#define SYSPROC_H
#include "../include/stdint.h"

extern int64_t sys_exit();

#endif /* SYSPROC_H */