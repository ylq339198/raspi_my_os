# ToyOS
A simple SMP OS on ARMv8a

这是我的毕业设计项目,一个计划在树莓派3上可以运行的类Unix操作系统

我会将实现这个项目的历程放在知乎上与大家分享

https://zhuanlan.zhihu.com/p/431589067